// pages/allrepair/allrepair.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
  
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //用于for循环的orderContent
    var orderContent = [
      {
        orderNumber: "201801161237",
        hospital: "协和医院",
        orderTime: "2018-01-16",
        status: "未处理"
      },
      {
        orderNumber: "201801161236",
        hospital: "同济医院",
        orderTime: "2018-01-13",
        status: "进行中"

      },
      {
        orderNumber: "201801161235",
        hospital: "人民医院",
        orderTime: "2018-01-12",
        status: "已完成"
      },
      {
        orderNumber: "201801161234",
        hospital: "华西医院",
        orderTime: "2018-01-11",
        status: "已完成"
      }
    ];

    this.setData({ allOrder: orderContent });
  },


  clickDetail: function () {
    wx.navigateTo({
      url: '../detail/detail',
    })
  },

  clickApponitEngineer: function () {
    wx.navigateTo({
      url: '../appointEngineer/appointEngineer',
    })
  },

  clickSearch:function(){
    wx.navigateTo({
      url: '../search/search',
    })
  },

  clickFilter: function () {
    wx.navigateTo({
      url: '../filter/filter',
    })
  },
  
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})